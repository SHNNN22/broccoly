function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(201,68,194);


}
